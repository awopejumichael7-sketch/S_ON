/* ════════════════════════════════════════════════════════
   APP-AUTH-INTEGRATION.JS
   Wires the login screen to Firebase Auth, gates the app
   behind login, and hooks exam submission into Firestore.

   Load order in index.html (just before </body>, AFTER
   questions.js and script.js, and AFTER the Firebase SDK):

     <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js"></script>
     <script src="firebase-config.js"></script>
     <script src="auth.js"></script>
     <script src="firestore.js"></script>
     <script src="questions.js"></script>
     <script src="script.js"></script>
     <script src="app-auth-integration.js"></script>
   ════════════════════════════════════════════════════════ */

const AppAuthUI = {
  mode: "login", // "login" | "signup"

  toggleMode(e) {
    if (e) e.preventDefault();
    AppAuthUI.mode = AppAuthUI.mode === "login" ? "signup" : "login";
    const isSignup = AppAuthUI.mode === "signup";

    document.getElementById("auth-title").textContent = isSignup ? "Create Account" : "Sign In";
    document.getElementById("auth-submit-btn").textContent = isSignup ? "Sign Up" : "Sign In";
    document.getElementById("auth-name-group").style.display = isSignup ? "block" : "none";
    document.getElementById("auth-toggle-text").textContent = isSignup
      ? "Already have an account?"
      : "Don't have an account?";
    document.getElementById("auth-toggle-link").textContent = isSignup ? "Sign In" : "Sign Up";
    AppAuthUI.clearError();
  },

  showError(msg) {
    const el = document.getElementById("auth-error");
    el.textContent = msg;
    el.style.display = "block";
  },

  clearError() {
    document.getElementById("auth-error").style.display = "none";
  },

  async submit() {
    AppAuthUI.clearError();
    const email = document.getElementById("auth-email").value.trim();
    const password = document.getElementById("auth-password").value;

    if (!email || !password) {
      AppAuthUI.showError("Please fill in all fields.");
      return;
    }

    const btn = document.getElementById("auth-submit-btn");
    btn.disabled = true;
    btn.textContent = "Please wait…";

    let result;
    if (AppAuthUI.mode === "signup") {
      const name = document.getElementById("auth-name").value.trim();
      if (!name) {
        AppAuthUI.showError("Please enter your name.");
        btn.disabled = false;
        btn.textContent = "Sign Up";
        return;
      }
      result = await Auth.signup(name, email, password);
    } else {
      result = await Auth.login(email, password);
    }

    btn.disabled = false;
    btn.textContent = AppAuthUI.mode === "signup" ? "Sign Up" : "Sign In";

    if (!result.success) {
      AppAuthUI.showError(result.error);
    }
    // onAuthStateChanged (Auth.init below) handles the screen switch on success
  },

  async forgotPassword() {
    const email = document.getElementById("auth-email").value.trim();
    if (!email) {
      AppAuthUI.showError("Enter your email above first, then click 'Forgot password?'");
      return;
    }
    const result = await Auth.resetPassword(email);
    if (result.success) {
      AppAuthUI.showError("Password reset email sent. Check your inbox.");
    } else {
      AppAuthUI.showError(result.error);
    }
  }
};

// ── Screen switching helpers ──────────────────────────────
function showLoginScreen() {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById("screen-login").classList.add("active");
}

function showAppAfterLogin(user) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById("screen-dashboard").classList.add("active");

  // Inject a small user badge + logout button into the header, if not present
  const headerActions = document.querySelector(".header-actions");
  if (headerActions && !document.getElementById("user-badge")) {
    const badge = document.createElement("div");
    badge.id = "user-badge";
    badge.className = "user-badge";
    badge.innerHTML = `
      <span>👤 ${user.displayName || user.email}</span>
      <button class="btn-icon" title="Log out" aria-label="Log out" onclick="Auth.logout()">🚪</button>
    `;
    headerActions.prepend(badge);
  }
}

// ── Gate the whole app behind auth state ──────────────────
Auth.init(
  (user) => showAppAfterLogin(user),
  () => showLoginScreen()
);

/* ────────────────────────────────────────────────────────
   Hook into exam submission so every finished attempt is
   saved to Firestore automatically (in addition to whatever
   localStorage logic script.js already does).

   This wraps CBT.confirmSubmit if it exists, without
   needing to edit script.js itself. Adjust field names
   (subject/score/correct/wrong/skipped/timeSpent/answers)
   to match whatever your CBT object actually stores —
   check script.js for the real property names and tweak
   the object below.
   ──────────────────────────────────────────────────────── */
(function hookExamSubmit() {
  if (typeof CBT === "undefined" || !CBT.confirmSubmit) return;

  const originalConfirmSubmit = CBT.confirmSubmit.bind(CBT);

  CBT.confirmSubmit = function (...args) {
    const result = originalConfirmSubmit(...args);

    // Best-effort: pull current exam state off CBT's internal state object.
    // Replace `CBT.state` below with whatever variable actually holds it.
    try {
      const state = CBT.state || CBT.currentExam || {};
      ExamDB.saveAttempt({
        subject: state.subject || "unknown",
        score: state.scorePercent ?? state.score ?? 0,
        correct: state.correctCount ?? 0,
        wrong: state.wrongCount ?? 0,
        skipped: state.skippedCount ?? 0,
        timeSpent: state.timeSpent ?? 0,
        answers: state.answers || {}
      });
    } catch (e) {
      console.warn("Could not auto-save attempt to Firestore:", e);
    }

    return result;
  };
})();
