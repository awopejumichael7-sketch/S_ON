# Firebase Add-On for School-_of_nursing CBT App

This folder adds **Firebase Authentication (login/signup)** and **full Firestore CRUD**
(Create, Read, Update, Delete) for exam attempts and user profiles to your existing
static app, without touching your existing exam logic.

## Files

| File | Purpose |
|---|---|
| `firebase-config.js` | Your Firebase project keys + SDK init |
| `auth.js` | Login, signup, logout, password reset |
| `firestore.js` | CRUD functions: `ExamDB.saveAttempt/getAttempts/getAttempt/updateAttempt/deleteAttempt/clearHistory`, plus profile read/update |
| `firestore.rules` | Security rules — each user can only access their own data |
| `login-screen.html` | The login/signup screen markup |
| `auth-styles.css` | Styling for the login screen |
| `app-auth-integration.js` | Glue code: shows/hides screens based on login state, auto-saves exam results |

## Setup steps

### 1. Create the Firebase project
1. Go to https://console.firebase.google.com → **Add project**.
2. In **Build → Authentication → Sign-in method**, enable **Email/Password**.
3. In **Build → Firestore Database**, click **Create database** (production mode, pick a region).
4. In **Project settings → General → Your apps**, click the **Web (`</>`)** icon to register a web app, then copy the `firebaseConfig` object it shows you.
5. Paste those values into `firebase-config.js` in this folder (replace the `YOUR_...` placeholders).

### 2. Publish the security rules
In the Firebase console, go to **Firestore Database → Rules**, paste in the contents of `firestore.rules`, and click **Publish**.

### 3. Copy files into your repo
Copy these into the root of `School-_of_nursing` (same folder as `index.html`):
```
firebase-config.js
auth.js
firestore.js
app-auth-integration.js
```

### 4. Edit `index.html`
**a)** Add the Firebase SDK + your new scripts right before `</body>`, in this exact order:
```html
<script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js"></script>
<script src="firebase-config.js"></script>
<script src="auth.js"></script>
<script src="firestore.js"></script>
<script src="questions.js"></script>
<script src="script.js"></script>
<script src="app-auth-integration.js"></script>
```
Remove the old `<script src="questions.js">` / `<script src="script.js">` tags from wherever they currently are, since they're now included above in the correct order.

**b)** Paste the contents of `login-screen.html` right after the `<header>` block and before `<section id="screen-dashboard" ...>`.

**c)** On the existing `screen-dashboard` section, remove the `active` class (the login screen is now the first one shown):
```html
<section id="screen-dashboard" class="screen" aria-label="Dashboard">
```

### 5. Edit `style.css`
Append the entire contents of `auth-styles.css` to the end of `style.css`.

### 6. Double check the auto-save hook
Open `app-auth-integration.js` and look at the `hookExamSubmit()` function near the bottom.
It assumes your `script.js` keeps exam state on something like `CBT.state` — open `script.js`,
find the actual variable that holds `subject`, `score`, `correct`, `wrong`, `skipped`, `timeSpent`,
and `answers` after an exam finishes, and update the field names in that function to match.
(If you'd like, paste me the relevant section of `script.js` and I'll wire this up exactly.)

### 7. Test it
Open `index.html` in a browser (or push to GitHub Pages). You should see:
- A login/signup screen first.
- After signing up, a new document appears under **Firestore → users → {uid}**.
- After finishing an exam, a new document appears under **users/{uid}/attempts**.
- A 🚪 logout button appears in the header.

## CRUD reference (use anywhere after login)

```js
// CREATE
await ExamDB.saveAttempt({ subject: "physics", score: 85, correct: 51, wrong: 9, skipped: 0, timeSpent: 3200, answers: {} });

// READ all attempts (optionally filter by subject)
const { attempts } = await ExamDB.getAttempts("physics");

// READ one attempt
const { attempt } = await ExamDB.getAttempt(attemptId);

// UPDATE
await ExamDB.updateAttempt(attemptId, { score: 90 });

// DELETE one
await ExamDB.deleteAttempt(attemptId);

// DELETE all (clear history)
await ExamDB.clearHistory("physics");

// Profile
const { profile } = await ExamDB.getProfile();
await ExamDB.updateProfile({ name: "New Name" });
```

## Pushing to GitHub
Since I don't have write access to your repository, commit these changes yourself:
```bash
git add firebase-config.js auth.js firestore.js app-auth-integration.js index.html style.css
git commit -m "Add Firebase auth and Firestore CRUD for exam attempts"
git push
```
